package com.javabycode.security;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class MySecurityWebApplicationInitializer extends AbstractSecurityWebApplicationInitializer{

}
